#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T,typename... Args> void pr(T a, Args... args) {std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;
const int MM = 2005;


int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);

	int n;
	cin>>n;

	cout<<"? 1"<<endl;
	vector<int> v[2];
	for(int i = 1,a; i <= n; i++){
		cin>>a;
		v[a%2].emplace_back(i);
	}
	if(size(v[0]) > size(v[1]))
		swap(v[0], v[1]);

	vector<pair<int, int>> ans;

	for(int i: v[0]){
		cout<<"? "<<i<<endl;
		for(int j = 1,a; j <= n; j++){
			cin>>a;
			if(a == 1){
				ans.emplace_back(i, j);
			}
		}
	}

	cout<<"!\n";
	for(auto [a, b]: ans)
		cout<<a<<' '<<b<<'\n';
	cout<<flush;
}