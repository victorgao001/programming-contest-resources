import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class D {
	static final long MOD = 1000000007;
	
	static int n;

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		n = readInt();
		int[] r1 = read(1);
		ArrayList<Integer>[] ns = new ArrayList[2];
		for (int i = 0; i < 2; i++) ns[i] = new ArrayList<>();
		TreeSet<Pair<Integer, Integer>> es = new TreeSet<>();
		
		for (int i = 2; i <= n; i++) {
			ns[r1[i] % 2].add(i);
			if (r1[i] == 1)
				es.add(new Pair<>(1, i));
		}
		int idx = ns[0].size() < ns[1].size() ? 0 : 1;
		for (int r : ns[idx]) {
			int[] rx = read(r);
			for (int i = 1; i <= n; i++)
				if (rx[i] == 1)
					es.add(new Pair<>(Math.min(r, i), Math.max(r, i)));
		}
		
		System.out.println("!");
		for (Pair<Integer, Integer> p : es)
			if (p.f < p.s)
				System.out.println("" + p.f + " " + p.s);
	}
	
	static int[] read(int r) throws IOException {
		System.out.println("? " + r);
		int[] res = new int[n+1];
		for (int i = 1; i <= n; i++) res[i] = readInt();
		return res;
	}
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
    static String next() throws IOException {
    	while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(br.readLine().trim());
    	return st.nextToken();
    }
    static long readLong() throws IOException {
    	return Long.parseLong(next());
	}
    static int readInt() throws IOException {
    	return Integer.parseInt(next());
    }
    static short readShort() throws IOException{
    	return Short.parseShort(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter() throws IOException {
        return next().charAt(0);
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
    
    static class Pair<T extends Comparable<T>, U extends Comparable<U>> implements Comparable<Pair<T, U>> {
    	T f;
    	U s;
    	public Pair(T f0, U s0) {
    		f = f0;
    		s = s0;
    	}
    	
		@Override
		public int compareTo(Pair<T, U> o) {
			int fc = f.compareTo(o.f);
			return fc == 0 ? s.compareTo(o.s) : fc;
		}
    }
}
