from sys import stdin, stdout, setrecursionlimit, exit
input = stdin.readline
flush = stdout.flush
gi = lambda: list(map(int, input().split()))

N = int(input())
TARGET = N - 1
init = []

def query(root):
    if root == 1 and init: return init
    print("? %d" % root)
    flush()
    return [0] + gi()

init = query(1)
par = [i & 1 for i in init]
tgt = int(par.count(0) - 2 >= par.count(1))
edges = {(1, i) for i in range(2, N + 1) if init[i] == 1}
for i in range(2, N + 1):
    if len(edges) == TARGET: break
    if init[i] % 2 == tgt:
        cur = query(i)
        for j in range(1, N + 1):
            if cur[j] == 1:
                edges.add((min(i, j), max(i, j)))
print("!")
flush()
for i, j in edges:
    print("%d %d" % (i, j))

