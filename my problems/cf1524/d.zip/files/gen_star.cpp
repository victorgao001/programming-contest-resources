#include "bits/stdc++.h"
#include "testlib.h"
using namespace std;
using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
template<typename T>
int sz(const T &a){return (int)a.size();}
const int MN=1e5+1;
int parent[MN];
int main(int argc, char* argv[]){
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    registerGen(argc,argv,0);
    int n=stoi(argv[1]),rt=stoi(argv[2]);

    vector<pii> es;
    for (auto i = 0; i < n; i++)
        if (i != rt)
            es.emplace_back(rt, i);
    for (auto &[a, b] : es) {
        if (rnd.next(0, 1))
            swap(a, b);
    }
    shuffle(es.begin(), es.end());

    cout << (n) << '\n';
    for (auto [a, b] : es)
        cout << (a+1) << ' ' << (b+1) << '\n';

    return 0;
}
