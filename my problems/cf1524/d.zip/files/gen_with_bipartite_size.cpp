#include "bits/stdc++.h"
#include "testlib.h"
using namespace std;
using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
template<typename T>
int sz(const T &a){return (int)a.size();}
const int MN=1e5+10;
int parent[MN];
int main(int argc, char* argv[]){
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    registerGen(argc,argv,0);
    int n=stoi(argv[1]),t=stoi(argv[2]), sz1=stoi(argv[3]);//t is the elongation https://codeforces.com/blog/entry/18291

    vector<int> p(n); iota(p.begin(), p.end(), 0); shuffle(p.begin(), p.end());

    auto moveVal = [&] (vector<int> &v, int val, int idx) {
        int cidx = find(v.begin(), v.end(), val) - v.begin();
        v.erase(v.begin()+cidx);
        v.insert(v.begin()+idx, val);
    };
    moveVal(p, 0, 0);
    moveVal(p, 1, n-1);

    vector<bool> setno(n);
    for (auto i = 0; i < sz1; i++) setno[p[i]] = 1;

    vector<int> sets[2];
    sets[setno[0]].push_back(0);

    cout << (n) << '\n';
    for(int i=1;i<n;i++){
        vector<int> &v = sets[!setno[i]];
        parent[i] = v[rnd.wnext(0, (int)v.size()-1, t)];

        sets[setno[i]].push_back(i);
    }

    vector<int> perm(n);
    for(int i=0;i<n;i++)perm[i]=i+1;
    shuffle(perm.begin(),perm.end());
    vector<pii> edges;
    for(int i=1;i<n;i++){
        edges.push_back({perm[parent[i]],perm[i]});
    }
    shuffle(edges.begin(),edges.end());
    for (auto [a, b] : edges)
        cout << (a) << ' ' << (b) << '\n';

    return 0;
}
