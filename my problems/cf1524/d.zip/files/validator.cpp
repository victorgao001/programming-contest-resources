#include "testlib.h"
#include "bits/stdc++.h"
using namespace std;

const int MN = 2001;
int dsu[MN];
int rt(int x) { return dsu[x] == x ? x : dsu[x] = rt(dsu[x]); }

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(2, 2000, "N");
    inf.readEoln();

    iota(dsu, dsu+MN, 0);
    for (auto i = 0; i < N-1; i++) {
        int a = inf.readInt(1, N, "a_" + to_string(i));
        inf.readSpace();
        int b = inf.readInt(1, N, "b_" + to_string(i));
        inf.readEoln();

        ensuref(rt(a) != rt(b), "edge %d to %d creates cycle", a, b);
        dsu[rt(b)] = rt(a);
    }

    inf.readEof();
}

