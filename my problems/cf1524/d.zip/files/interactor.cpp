#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using pii = pair<int, int>;

const int MN = 2000 + 1;
int N,
    dep[MN];
vector<int> g[MN];

int stk[MN], ptr = 0;
void dfs(int st) {
    fill(dep, dep+N+1, -1);
    ptr = 0;
    dep[st] = 0; stk[ptr++] = st;
    while (ptr > 0) {
        int c = stk[--ptr];
        for (auto to : g[c]) {
            if (dep[to] == -1) {
                dep[to] = dep[c] + 1;
                stk[ptr++] = to;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    registerInteraction(argc, argv);

    // get input and output tree to user
    N = inf.readInt();
    cout << N << '\n'; cout.flush();
    for (auto i = 0; i < N-1; i++) {
        int a = inf.readInt(), b = inf.readInt();
        g[a].push_back(b);
        g[b].push_back(a);
    }

    // begin interaction
    int queriesLeft = (N+1) / 2;
    string s = ouf.readWord();
    while (true) {
        if (s == "!") {
            vector<pii> user_edges;
            for (auto i = 0; i < N-1; i++) {
                int user_A = ouf.readInt(1, N), user_B = ouf.readInt(1, N);
                if (user_A > user_B) swap(user_A, user_B);
                user_edges.emplace_back(user_A, user_B);
            }
            sort(user_edges.begin(), user_edges.end());

            for (auto [a, b] : user_edges)
                tout << a << ' ' << b << '\n';

            quitf(_ok, "used %d queries", (N+1)/2 - queriesLeft); // answer to be checked by checker
            return 0;
        }
        else if (s == "?") {
            if (queriesLeft == 0) quitf(_wa, "participant tried to use more than %d queries", (N+1)/2);
            int user_R = ouf.readInt(1, N);
            dfs(user_R);
            for (auto i = 1; i <= N; i++)
                cout << dep[i] << " \n"[i == N];
            cout.flush();

            queriesLeft--;
        }
        else
            quitf(_wa, "invalid query type %s", s.c_str());

        s = ouf.readWord();
    }
}

