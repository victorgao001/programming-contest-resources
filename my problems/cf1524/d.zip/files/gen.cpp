#include "bits/stdc++.h"
#include "testlib.h"
using namespace std;
using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
template<typename T>
int sz(const T &a){return (int)a.size();}
const int MN=2e3+10;
int parent[MN];
int main(int argc, char* argv[]){
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    registerGen(argc,argv,0);
    int n=stoi(argv[1]),t=stoi(argv[2]);//t is the elongation https://codeforces.com/blog/entry/18291
    printf("%d\n",n);
    for(int i=1;i<n;i++){
        parent[i]=rnd.wnext(i,t);
    }
    vector<int> perm(n);
    for(int i=0;i<n;i++)perm[i]=i+1;
    shuffle(perm.begin(),perm.end());
    vector<pii> edges;
    for(int i=1;i<n;i++){
        edges.push_back({perm[parent[i]],perm[i]});
    }
    shuffle(edges.begin(),edges.end());
    for(auto x:edges)printf("%d %d\n",x.first,x.second);

    return 0;
}
