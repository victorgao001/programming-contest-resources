#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int MN = 501, MAXQ = 500;
int N, K, queryCnt = 0,
    A[MN];

void processCode(string s) {
    if (s == "!") {
        int ans = ouf.readInt();
        tout << queryCnt << ' ' << ans << '\n';
        quitf(_ok, "processed %d queries", queryCnt);
    }
    else if (s == "?") {
        queryCnt++;
        if (queryCnt > MAXQ) quitf(_wa, "contestant made more than %d (hard limit) queries", MAXQ);

        vector<bool> used(N);
        int res = 0;
        for (auto i = 0; i < K; i++)  {
            int ind = ouf.readInt(1, N)-1;
            if (used[ind]) quitf(_wa, "query %d used index %d multiple times", queryCnt+1, ind+1);
            used[ind] = true;
            res ^= A[ind];
        }
        cout << res << endl;
    }
    else quitf(_wa, "invalid token %s beginning statement (expected ? or !)", s.c_str());
}

// endl flushes right????
int main(int argc, char *argv[]) {
    registerInteraction(argc, argv);

    N = inf.readInt();
    K = inf.readInt();
    cout << N << ' ' << K << endl; 

    // get input
    for (auto i = 0; i < N; i++) A[i] = inf.readInt();

    // begin interaction
    string s = ouf.readWord();
    if (s == "-1") {
        tout << "-1 -1\n";
        quitf(_ok, "test case is impossible");
    }
    else processCode(s);

    // begin interaction loop
    while (true)
        processCode(ouf.readWord());
}
