#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(1, 500, "N");
    inf.readSpace();
    inf.readInt(1, N, "K");
    inf.readEoln();

    for (auto i = 0; i < N; i++) {
        inf.readInt(1, 1000000000, "a_i");
        if (i < N-1) inf.readSpace();
        else inf.readEoln();
    }

    inf.readEof();
}
