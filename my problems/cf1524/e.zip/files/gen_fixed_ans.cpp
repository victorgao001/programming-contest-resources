#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

const int VMAX = 1e9;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    assert(argc == 9);
    int Nmin = atoi(argv[1]), Nmax = atoi(argv[2]), Kmin = atoi(argv[3]), Kmax = atoi(argv[4]), Vmin = atoi(argv[5]), Vmax = atoi(argv[6]), impossible = atoi(argv[7]), ans = atoi(argv[8]);

    int N = rnd.next(Nmin, Nmax);
    while (impossible && N % 2 == 0)
        N = rnd.next(Nmin, Nmax);

    if (Kmax > N) {
        int d = Kmax-N;
        Kmax -= d;
        Kmin -= d;
        Kmin = max(Kmin, 1);
    }

    auto getK = [&] () { return rnd.next(Kmin, Kmax); };
    int K = getK();
    while (impossible && K % 2 == 1)
        K = getK();
    while (!impossible && N % 2 == 1 && K % 2 == 0)
        K = getK();

    cout << N << ' ' << K << '\n';

    vector<int> A(N);
    int cur = 0;
    for (auto i = 0; i < N-2; i++) {
        int x = rnd.next(Vmin, Vmax);
        cur ^= x;
        A[i] = x;
    }
    int req = ans ^ cur, a = 0, b = req;
    for (auto i = 29; i >= 0; i--) {
        int bit = 1 << i;
        if (req & bit) {
            if ((a ^ bit) <= VMAX && (b ^ bit) != 0) {
                a ^= bit;
                b ^= bit;
            }
        }
    }
    A[N-2] = a;
    A[N-1] = b;
    shuffle(A.begin(), A.end());
    for (auto i = 0; i < N; i++)
        cout << A[i] << " \n"[i == N-1];
}
