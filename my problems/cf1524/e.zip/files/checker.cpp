#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main(int argc, char *argv[]) {
    setName("checker for problem d");
    registerTestlibCmd(argc, argv);

    int N = inf.readInt(), true_ans = 0; inf.readInt(); // read K as well, but we don't need it
    for (auto i = 0; i < N; i++)
        true_ans ^= inf.readInt();

    int user_numq = ouf.readInt(), user_ans = ouf.readInt(),
        jury_numq = ans.readInt(), jury_ans = ans.readInt();
    
    if (jury_numq == -1) ensuref(jury_ans == -1, "jury answer should give -1 for no queries");
    else ensuref(0 <= jury_ans && jury_ans <= 2e9, "jury answer is not in the expected range");
    

    if (jury_numq != -1 && jury_ans != true_ans) quitf(_fail, "intended solution gives incorrect answer, got %d, expected %d", jury_ans, true_ans);
    if (jury_numq == -1 && user_numq != -1) quitf(_wa, "user tried to solve impossible case");

    if (user_ans == jury_ans) {
        if (user_numq > jury_numq) quitf(_wa, "too many queries: participant made %d queries, expected %d", user_numq, jury_numq);
        else if (user_numq < jury_numq) quitf(_ok, "participant found better solution in %d queries, expected %d", user_numq, jury_numq); // It's possible the participant guessed a better solution using a non-deterministic code
        else { 
            if (user_numq != -1) quitf(_ok, "%d queries", user_numq);
            else quitf(_ok, "no solution exists");
        }
    }
    else quitf(_wa, "participant got answer %d, expected %d", user_ans, jury_ans);
}
