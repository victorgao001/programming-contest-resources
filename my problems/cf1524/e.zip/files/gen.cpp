#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    int Nmin = atoi(argv[1]), Nmax = atoi(argv[2]), Kmin = atoi(argv[3]), Kmax = atoi(argv[4]), Vmin = atoi(argv[5]), Vmax = atoi(argv[6]), impossible = atoi(argv[7]);


    int N = rnd.next(Nmin, Nmax);
    while (impossible && N % 2 == 0)
        N = rnd.next(Nmin, Nmax);

    if (Kmax > N) {
        int d = Kmax-N;
        Kmax -= d;
        Kmin -= d;
        Kmin = max(Kmin, 1);
    }

    auto getK = [&] () { return rnd.next(Kmin, Kmax); };
    int K = getK();
    while (impossible && K % 2 == 1)
        K = getK();
    while (!impossible && N % 2 == 1 && K % 2 == 0)
        K = getK();

    cout << N << ' ' << K << '\n';
    for (auto i = 0; i < N; i++)
        cout << rnd.next(Vmin, Vmax) << " \n"[i == N-1];
}
