#include "bits/stdc++.h"
using namespace std;

int main() {
    int N, K; cin >> N >> K;

    cout << "? ";
    for (auto i = 0; i < K; i++) cout << "0 ";
    cout << endl;
    
    int __tmp; cin >> __tmp;
    
    cout << "! 0" << endl;
}
