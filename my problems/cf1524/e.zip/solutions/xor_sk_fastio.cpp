/**
 * Sergey Kopeliovich (burunduk30@gmail.com)
 */

#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define all(a) (a).begin(), (a).end()

/** Fast input-output */

template <class T> inline void writeInt( T x, char end = 0, int len = -1 );
inline void writeChar( int x ); 
inline void writeWord( const char *s );
inline void flush();

static struct buffer_flusher_t {
    ~buffer_flusher_t() {
        flush();
    }
} buffer_flusher;

static const int buf_size = 4096;
static int write_buf_pos = 0;
static char write_buf[buf_size];

inline void writeChar( int x ) {
    if (write_buf_pos == buf_size)
        fwrite(write_buf, 1, buf_size, stdout), write_buf_pos = 0;
    write_buf[write_buf_pos++] = x;
}

inline void flush() {
    if (write_buf_pos) {
        fwrite(write_buf, 1, write_buf_pos, stdout), write_buf_pos = 0;
        fflush(stdout);
    }
}

template <class T> 
inline void writeInt( T x, char end, int output_len ) {
    if (x < 0)
        writeChar('-'), x = -x;

    char s[24];
    int n = 0;
    while (x || !n)
        s[n++] = '0' + x % 10, x /= 10;
    while (n < output_len)
        s[n++] = '0';
    while (n--)
        writeChar(s[n]);
    if (end)
        writeChar(end);
}

inline void writeWord( const char *s ) {
    while (*s)
        writeChar(*s++);
}

int main() {
	int n, k, m = 1;
    cin >> n >> k;
    vector<int> cnt(n, 1);
    int sum = n, i = 0;
    if (k != n) {
    	while (sum <= n * n && (sum < m * k || sum % k != 0)) {
    		m = max(m, cnt[i] += 2);
    		sum += 2, i = (i + 1) % n;
    	}
    }
    if (sum > n * n) {
        puts("-1");
        return 0;
    }

    int qn = sum / k, j = 0;

    vector<vector<int>> q(qn);
    forn(i, n)
    	if (cnt[i] >= 3) 
    		while (cnt[i]--)
    			q[j++].push_back(i), j %= qn;
    j = 0;
    forn(i, n)
    	if (cnt[i] > 0) {
    		while (j < qn && (int)q[j].size() == k)
    			j++;
            assert(j < qn);
    		q[j].push_back(i);
    	}

    int ans = 0, x;
    for (auto &a : q) {
    	writeWord("? ");
    	for (int i : a) writeInt(i + 1, ' ');
        writeChar('\n'), flush();
    	cin >> x;
    	ans ^= x;
    }
    writeWord("! "), writeInt(ans, '\n');
}
