/**
 * Sergey Kopeliovich (burunduk30@gmail.com)
 */

#include <bits/stdc++.h>

using namespace std;

#define forn(i, n) for (int i = 0; i < (int)(n); i++)
#define all(a) (a).begin(), (a).end()

int main() {
	int n, k, m = 1;
    cin >> n >> k;
    vector<int> cnt(n, 1);
    int sum = n, i = 0;
    if (k != n) {
    	while (sum <= n * n && (sum < m * k || sum % k != 0)) {
    		m = max(m, cnt[i] += 2);
    		sum += 2, i = (i + 1) % n;
    	}
    }
    if (sum > n * n) {
        puts("-1");
        return 0;
    }

    int qn = sum / k, j = 0;

    vector<vector<int>> q(qn);
    forn(i, n)
    	if (cnt[i] >= 3) 
    		while (cnt[i]--)
    			q[j++].push_back(i), j %= qn;
    j = 0;
    forn(i, n)
    	if (cnt[i] > 0) {
    		while (j < qn && (int)q[j].size() == k)
    			j++;
            assert(j < qn);
    		q[j].push_back(i);
    	}

    int ans = 0, x;
    for (auto &a : q) {
    	printf("?");
    	for (int i : a) printf(" %d", i + 1);
    	puts(""), fflush(stdout);
    	cin >> x;
    	ans ^= x;
    }
    printf("! %d\n", ans);
}
