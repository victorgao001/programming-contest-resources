from sys import stdin, stdout, setrecursionlimit, exit
input = stdin.readline
flush = stdout.flush
gi = lambda: list(map(int, input().split()))

N, K = gi()
def query(array):
    print("? %s" % (" ".join(map(str, array))))
    flush()
    return int(input())

dist = [-1] * (N + 1)
prev = [-1] * (N + 1)
dist[0] = 0
queue = [0]
for node in queue:
    for overlap in range(0, min(node, K) + 1):
        nx = node + K - 2 * overlap
        if not 0 <= nx <= N: continue
        if dist[nx] == -1 and node + (K - overlap) <= N:
            dist[nx] = dist[node] + 1
            prev[nx] = node, overlap
            queue.append(nx)
if dist[N] == -1:
    print(-1)
    exit(0)
cur = N
order = []
while prev[cur] != -1:
    order.append(prev[cur])
    cur = prev[cur][0]
active = set()
remain = set(range(1, N + 1))
xor = 0
for sz, overlap in order[::-1]:
    to_query = set(list(active)[:overlap])
    to_remove = set(to_query)
    to_query |= set(list(remain)[:K - overlap])
    xor ^= query(list(to_query))
    active = (active | to_query) - to_remove
    remain = (remain - to_query) | to_remove
print("! %d" % xor)