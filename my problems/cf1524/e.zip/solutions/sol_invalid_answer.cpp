#include "bits/stdc++.h"
using namespace std;

int main() {
    int N, K; cin >> N >> K;

    cout << "! -1" << endl;
}
