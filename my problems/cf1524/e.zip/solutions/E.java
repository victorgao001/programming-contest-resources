import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class E {
	static int INF = 0x3f3f3f3f;

	public static void main(String[] args) throws IOException {
		int N = readInt(), K = readInt();
		int[] dis = new int[N+1], par = new int[N+1];
	 
	    // BFS
		Arrays.fill(dis, INF);
	    Queue<Integer> q = new LinkedList<>();
	    dis[0] = 0; par[0] = -1; q.add(0);
	    while (!q.isEmpty()) {
	        int c = q.poll(); // c -> num selected
	        for (int i = 0; i <= K; i++) { // num unselected we add
	            if (i <= N-c && K-i <= c) {
	                int to = c + i-(K-i);
	                if (dis[to] == INF) {
	                    dis[to] = dis[c]+1;
	                    par[to] = c;
	                    q.add(to);
	                }
	            }
	        }
	    }
	 
	    if (dis[N] == INF) System.out.println(-1);
	    else {
	        // get ans
	        ArrayList<Integer> path = new ArrayList<>();
	        for (int c = N; c != -1; c = par[c])
	            path.add(c);
	        Collections.reverse(path);
	        
	        boolean[] sel = new boolean[N+1];
	 
	        int sz = path.size(), ans = 0;
	        for (int i = 0; i < sz-1; i++) {
	            // a-(K-a) = d
	            // a-K+a=d
	            // 2a-K=d
	            // 2a=d+K
	            // a=(d+K)/2
	            int a = path.get(i), b = path.get(i+1), d = b-a, nsel = (d+K)/2, nnosel = K-nsel; assert((d+K) % 2 == 0);
	            
	            // make query
	            StringBuilder sb = new StringBuilder("?");
	            for (int j = 1; j <= N; j++) {
	            	if (nsel > 0 && !sel[j]) {
	            		nsel--;
	            		sel[j] = true;
	            		sb.append(' ').append(j);
	            	}
	            	else if (nnosel > 0 && sel[j]) {
	            		nnosel--;
	            		sel[j] = false;
	            		sb.append(' ').append(j);
	            	}
	            }
	            System.out.println(sb.toString());
	 
	            int res = readInt();
	            ans ^= res;
	        }
	        
	        System.out.println("! " + ans);
	    }
	}
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
    static String next() throws IOException {
    	while (st == null || !st.hasMoreTokens()) st = new StringTokenizer(br.readLine().trim());
    	return st.nextToken();
    }
    static long readLong() throws IOException {
    	return Long.parseLong(next());
	}
    static int readInt() throws IOException {
    	return Integer.parseInt(next());
    }
    static short readShort() throws IOException{
    	return Short.parseShort(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter() throws IOException {
        return next().charAt(0);
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
    
    static class Pair<T extends Comparable<T>, U extends Comparable<U>> implements Comparable<Pair<T, U>> {
    	T f;
    	U s;
    	public Pair(T f0, U s0) {
    		f = f0;
    		s = s0;
    	}
    	
		@Override
		public int compareTo(Pair<T, U> o) {
			int fc = f.compareTo(o.f);
			return fc == 0 ? s.compareTo(o.s) : fc;
		}
    }
}
