#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const ll INF = 0x3f3f3f3f;

const int MN = 2001;
int N, K;

int main() {
    cin >> N >> K;

    if (N % 2 == 1 && K % 2 == 0) return cout << "-1\n", 0;

    vector<int> sel, nosel(N);
    iota(nosel.begin(), nosel.end(), 1);

    int ans = 0;
    while ((int)nosel.size() >= K) {
        cout << "? ";
        for (auto i = 0; i < K; i++) {
            cout << nosel.back() << ' ';
            sel.push_back(nosel.back());
            nosel.pop_back();
        }
        cout << '\n'; cout.flush();
        int res; cin >> res;
        ans ^= res;
    }

    if (!nosel.empty() && (int)nosel.size() % 2 != K % 2) {
        assert(K % 2 == 1);

        cout << "? ";
        for (auto i = 0; i < K-1; i++) cout << sel.back() << ' ';
        cout << nosel.back();
        cout << '\n'; cout.flush();
        int res; cin >> res;
        ans ^= res;

        nosel.pop_back();
    }

    if (!nosel.empty()) {
        cout << "? ";
        for (auto i = 0; i < K-(int)nosel.size(); i++) cout << sel.back() << ' ';
        for (auto x : nosel) cout << x << ' ';
        cout << '\n'; cout.flush();
        int res; cin >> res;
        ans ^= res;
    }

    cout << "! " << ans << '\n'; cout.flush();
}
