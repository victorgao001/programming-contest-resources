#include <bits/stdc++.h>
#include "testlib.h"
#define all(x) (x).begin(), (x).end()

#ifdef LOCAL
template<typename T> void pr(T a){std::cerr<<a<<std::endl;}
template<typename T, typename... Args> void pr(T a, Args... args){std::cerr<<a<<' ',pr(args...);}
#else
template<typename... Args> void pr(Args... args){}
#endif

using namespace std;

vector<int> generatearray(int n, int mval, int type){
	vector<int> arr(n);
	if(type==1) {//decreasing
		for (int i = 0; i < n; i++) {
			arr[i] = rnd.next(0, mval);
		}
		sort(arr.begin(),arr.end(),greater<>());
		int cnt=max(1,int(n*0.03));
		for(int i=0;i<cnt;i++){
			int a=rnd.next(0,n-1),b=rnd.next(0,n-1);
			swap(arr[a],arr[b]);
		}
	}
	else if(type==2){//increasing
		for (int i = 0; i < n; i++) {
			arr[i] = rnd.next(0, mval);
		}
		sort(arr.begin(),arr.end());
		int cnt=max(1,int(n*0.03));
		for(int i=0;i<cnt;i++){
			int a=rnd.next(0,n-1),b=rnd.next(0,n-1);
			swap(arr[a],arr[b]);
		}
	}
	else if(type==3){//extreme
		for (auto i = 0; i < n; i++) {
			int m = -1 + 2*rnd.next(0, 1);
			arr[i]=rnd.wnext(0, mval, 40*m);
		}
	}
	else if(type==4){//close
		int offset=0.01*mval;
		int mid=rnd.next(offset,mval-offset);
		for(int i=0;i<n;i++){
			arr[i]=rnd.next(mid-offset,mid+offset);
		}
	}
	else{//random
		for(int i=0;i<n;i++){
			arr[i]=rnd.next(0,mval);
		}
	}
	return arr;
}

int main(int argc, char* argv[]){
	assert(argc >= 4);
	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	int t = atoi(argv[3]);
	// t is for type of the highest element in each col
	int p = atoi(argv[4]);
	// p is for probability (out of 100) that an element below a top one is 1
	int at = atoi(argv[5]);
	// at is which type of a_i in each column.

	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin.exceptions(cin.failbit);
	registerGen(argc, argv, 0);

	vector<vector<char>> c(n);
	for(auto &i: c) i.resize(m, '.');
	vector<int> sum(m);

	auto arr = generatearray(m, n, t);
	for(int i = 0; i < m; i++){
		assert(0 <= arr[i] and arr[i] <= n);
		int h = arr[i]-1;
		if(h >= 0){
			c[h][i] = '#',sum[i]++;
		}

		for(int j = 0; j < h; j++){
			if(rnd.next(1, 100) <= p){
				c[j][i] = '#';
				sum[i]++;
			}
		}
		if(at==2){
		    sum[i]=rnd.next(0,sum[i]);
		}
		else if(at==3){
		    for(int j = h+1; j < n; j++){
        		if(rnd.next(1, 100) <= p){
        			c[j][i] = '#';
        		}
		    }
		}
	}

	for(int i = 0; i < n/2; i++){
		for(int j = 0; j < m; j++){
			swap(c[i][j], c[n-1-i][j]);
		}
	}
	
	cout<<n<<' '<<m<<'\n';
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; j++){
			cout<<c[i][j];
		}
		cout<<'\n';
	}
	for(int i = 0; i < m; i++){
		cout<<sum[i]<<" \n"[i+1==m];
	}
   
}
