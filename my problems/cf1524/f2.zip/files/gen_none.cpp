#include "testlib.h"
#include <iostream>
#include <cassert>
using namespace std;
using ll = long long;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    int N = atoi(argv[1]), M = atoi(argv[2]), P = atoi(argv[3]);

    cout << (N) << ' ' << (M) << '\n';
    for (auto i = 0; i < N; i++) {
        for (auto j = 0; j < M; j++) {
            if (rnd.next(1, 100) <= P)
                cout << '#';
            else 
                cout << '.';
        }
        cout << '\n';
    }
    for (auto i = 0; i < M; i++)
        cout << 0 << " \n"[i == M-1];
}
