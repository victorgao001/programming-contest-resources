#include <bits/stdc++.h>
//#pragma GCC optimize("Ofast")
#define fori(a,b) for(int i=a;i<b;i++)
#define forj(a,b) for(int j=a;j<b;j++)
#define fork(a,b) for(int k=a;k<b;k++)
#define ford(i,a,b) for(int i=a;i>=b;i--)
#define seto(x,i) memset(x,i,sizeof x)
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
#define pf first
#define ps second
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;

int n,a,b;
double x,y,t,u[200010],v[200010];
int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    //freopen("", "r", stdin);
    cin>>n;
    fori(0,n)
        cin>>u[i]>>v[i];
    sort(u,u+n); reverse(u,u+n); sort(v,v+n); reverse(v,v+n);
    fori(0,n*2)
    {
        if(x>y)
        {
            x--;
            y+=u[a++]-1;
        }
        else
        {
            y--;
            x+=v[b++]-1;
        }
        t=max(t,min(x,y));
    }
    printf("%.4f",t);
    return 0;
}