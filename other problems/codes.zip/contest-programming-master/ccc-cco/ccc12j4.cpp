#include <bits/stdc++.h>
#define fori(a,b) for(int i=a;i<b;i++)
#define forj(a,b) for(int j=a;j<b;j++)
#define fork(a,b) for(int k=a;k<b;k++)
#define ford(i,a,b) for(int i=a;i>=b;i--)

using namespace std;

int n;
string s;

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    cin>>n>>s;
    fori(0,s.size())
    {
        cout<<(char)((s[i]-'A'-3*i-3-n+26*10)%26+'A');
    }
    return 0;
}